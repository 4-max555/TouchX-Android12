package com.touchx.android12;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.os.RemoteException;
import rikka.shizuku.Shizuku;

/** App-side coordinator. Never activates capture when the selected game is not foreground. */
public final class Bridge {
    private static volatile IInputBridge remote;
    private static boolean binding = false;
    private static final ServiceConnection connection = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) {
            remote = IInputBridge.Stub.asInterface(b);
            binding = false;
            if (appContext != null) refresh(appContext);
        }
        @Override public void onServiceDisconnected(ComponentName n) { remote = null; binding = false; }
    };
    private static volatile Context appContext;
    private Bridge() {}
    public static SharedPreferences prefs(Context c) {return c.getSharedPreferences("touchx12", Context.MODE_PRIVATE);}
    public static synchronized void connect(Context c) {
        appContext = c.getApplicationContext();
        if (binding || remote != null) return;
        try {
            if (!Shizuku.pingBinder() || Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) return;
            binding = true;
            Shizuku.UserServiceArgs args = new Shizuku.UserServiceArgs(
                new ComponentName(c.getPackageName(), InputMonitorService.class.getName()))
                .daemon(false).processNameSuffix("touch12").version(1);
            Shizuku.bindUserService(args, connection);
        } catch (Throwable e) { binding = false; remote = null; }
    }
    public static synchronized void refresh(Context c) {
        SharedPreferences p = prefs(c);
        boolean shouldRun = p.getBoolean("armed",false) && p.getBoolean("gameFocus",false);
        if (remote == null) {if (shouldRun) connect(c); return;}
        try {
            if (shouldRun && !remote.isActive()) {
                boolean started = remote.start(p.getFloat("x",1.30f),p.getFloat("y",1.40f));
                // Never keep reattempting an unavailable monitor whenever MIUI switches windows.
                if (!started) p.edit().putBoolean("armed", false).apply();
            }
            if (!shouldRun && remote.isActive()) remote.stop();
        } catch (RemoteException e) {remote=null;}
    }
    public static synchronized void stop(Context c) {
        prefs(c).edit().putBoolean("armed",false).putBoolean("gameFocus",false).apply();
        if (remote!=null) try {remote.stop();} catch(RemoteException ignored){}
    }
    public static String status() {
        try {
            if(!Shizuku.pingBinder()) return "Shizuku остановлен или не установлен";
            if(Shizuku.checkSelfPermission()!=PackageManager.PERMISSION_GRANTED) return "Shizuku: нужно разрешение";
            if(remote==null) return "Подключение к службе...";
            String error=remote.getLastError();
            if(!error.isEmpty()) return error;
            return remote.isActive()?"Активно в игре":"Готово (ожидание игры)";
        } catch(Throwable e){return "Ошибка подключения: "+e.getClass().getSimpleName();}
    }
}
