package com.touchx.android12;
interface IInputBridge {
   boolean start(float multiplierX, float multiplierY);
   void stop();
   boolean isActive();
   String getLastError();
}
