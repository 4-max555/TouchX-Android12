#!/usr/bin/env python3
"""Non-runtime, install-compatibility and safety invariants for the Android 12 source."""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
gradle = (root / 'app/build.gradle').read_text()
service = (root / 'app/src/main/java/com/touchx/android12/GameAccessibilityService.java').read_text()
monitor = (root / 'app/src/main/java/com/touchx/android12/InputMonitorService.java').read_text()
assert 'minSdk 31' in gradle, 'Android 12 (API 31) minimum required'
assert 'targetSdk 32' in gradle
assert 'KEYCODE_VOLUME_DOWN' in service and 'presses>=3' in service, 'Triple-volume abort missing'
assert 'return false' in service, 'Volume hardware events must not be consumed'
assert '120000' not in monitor and 'sessionEnd' not in monitor, 'Unexpected 120-second timer'
assert 'pilferPointers()' in monitor and 'injectInputEvent' in monitor
print('Static configuration checks OK. This does not prove touch capture works on MIUI 13.')
